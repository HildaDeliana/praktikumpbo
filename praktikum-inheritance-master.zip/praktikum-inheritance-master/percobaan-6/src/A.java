class A {
  String var_a = "Variable A";
  String var_b = "Variable B";
  String var_c = "Variable C";
  String var_d = "Variable D";

  A(){
    System.out.println("Konstruktor A dijalankan");
  }
}
